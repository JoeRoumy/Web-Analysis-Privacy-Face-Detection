import { TfjsImageRecognitionBase } from 'tfjs-image-recognition-base';

export type NetParams = {
  fc: TfjsImageRecognitionBase.FCParams
}

